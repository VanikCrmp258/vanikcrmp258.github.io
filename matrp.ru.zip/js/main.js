function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
    return pattern.test(emailAddress);
}
$(function () {
	
    $(".mobile_menu").click(function (e) {
        e.preventDefault();
        $("html").toggleClass("no_scroll");
        $(this).toggleClass("active");
        $(".nav_menu").toggleClass("active");
    });
    $(".dataimages").each(function () {
        $(this).css({
            background: "url(" + $(this).data("src") + ")",
            "background-size": $(this).data("size"),
            "background-position": "center",
            "background-repeat": "no-repeat",
        });
    });
    
    $('select').niceSelect();
	//Обработка доната
    var start = false;
	$("#donate").submit(function(event) {
		
		
		event.preventDefault();
		if($('#ofert').is(":checked")){
			
			var el = $(this);
			$.ajax({
					type: el.attr('method'),
					url: el.attr('action'),
					data: new FormData(this),
					contentType: false,
					cache: false,
				
					processData: false,
					success: function(result) {
					// console.log(result);
					json = jQuery.parseJSON(result);
					console.log(json);
					if(json.status == "warning") el.find('.alert').html(json.message);
					
					else {
						document.location.href = json.url;
						// alert(json.message);
						// $('#donate_window').hide();
						// $('#confirm_window').show();
						// $('#serverDonate').html(json.server_name);
						// $('#nickName').html(json.name);
						// $('#valueSum').html(json.sum);

						// if($('.x2').hasClass('disabled')) {
						// 	if(json.sum > 500 && json.sum < 1000)$('#pcCount').html(Math.round((json.sum) + json.sum*0.15));
						// 	else if(json.sum > 1000 && json.sum < 1500)$('#pcCount').html(Math.round((json.sum) + json.sum*0.2));
						// 	else if(json.sum > 1500)$('#pcCount').html(Math.round((json.sum) + json.sum*0.3));
						// 	else $('#pcCount').html(json.sum);
						// }
						// else $('#pcCount').html(json.sum*2);
						// $('#pay_go').attr('href',json.url);
						// $('#signature').val(json.message);
					}
					// console.log(result);
				
				
					
				}
			});
		
		}
		else return alert('Вы не подтвердили соглашение');
		
		
			
	});	
	
	$(".checkbox").click(function () {
		$(this).find('.block').toggleClass('active');
		if($(this).find('.block').hasClass('active')) $(this).find('input:checkbox').attr('checked', true);
		else $(this).find('input:checkbox').attr('checked', false);
	});
	$("#packages").submit(function(event) {
		
		
		event.preventDefault();
		if($('#ofert_modal').is(":checked")){
			// alert($('#email_confirm_modal').val());
			var el = $(this);
			if(!$('#email_confirm_modal').val())  return el.find('.alert').html('Почта не указана');
			if($('#email_confirm_modal').val() ) {
				if(!isValidEmailAddress($('#email_confirm_modal').val())) return el.find('.alert').html('Почта введена неверно');
				
			}
			
			$.ajax({
					type: $(this).attr('method'),
					url: $(this).attr('action'),
					data: new FormData(this),
					contentType: false,
					cache: false,
				
					processData: false,
					success: function(result) {
					
					json = jQuery.parseJSON(result);
					
					
					console.log(json);
					if(json.status == "warning") {
						// $('#modalBuy').modal('hide');
						el.find('.alert').html(json.message);
						// alert('Ошибка! Перезагрузите страницу');
					}
					else {
						
						window.location = json.url;
					}
					// else {
						
					// 	$('#sum_modal').val(datas.cost);
					// 	start_packages = 1;
					// 	$("#packages").attr("action","/getsign");
					// 	$("#packages").attr("method","POST");
					// 	$( "#pack_btn" ).trigger( "click" );
					// 	// $('#signature').val(json.message);
					// }
					// // console.log(result);
				
				
					
				}
			});
				
		}
		else return alert('Вы не подтвердили соглашение');	
		
		
			
	});	
	$("#donate_go").submit(function(event) {
		
		
		event.preventDefault();
		// if($('#ofert').is(":checked")){
			
			var el = $(this);
			$.ajax({
					type: el.attr('method'),
					url: el.attr('action'),
					data: new FormData(this),
					contentType: false,
					cache: false,
				
					processData: false,
					success: function(result) {
					// console.log(result);
					json = jQuery.parseJSON(result);
					console.log(json);
					if(json.status == "warning") el.find('.alert').html(json.message);
					
					else {
						document.location.href = json.url;
						// alert(json.message);
						// $('#donate_window').hide();
						// $('#confirm_window').show();
						// $('#serverDonate').html(json.server_name);
						// $('#nickName').html(json.name);
						// $('#valueSum').html(json.sum);

						// if($('.x2').hasClass('disabled')) {
						// 	if(json.sum > 500 && json.sum < 1000)$('#pcCount').html(Math.round((json.sum) + json.sum*0.15));
						// 	else if(json.sum > 1000 && json.sum < 1500)$('#pcCount').html(Math.round((json.sum) + json.sum*0.2));
						// 	else if(json.sum > 1500)$('#pcCount').html(Math.round((json.sum) + json.sum*0.3));
						// 	else $('#pcCount').html(json.sum);
						// }
						// else $('#pcCount').html(json.sum*2);
						// $('#pay_go').attr('href',json.url);
						// $('#signature').val(json.message);
					}
					// console.log(result);
				
				
					
				}
			});
		
		// }
		// else return alert('Вы не подтвердили соглашение');
		
		
			
	});	
    
});
var app = new Vue({
	el: '#app_block',
	data: {
		
	
	},
	methods: {
		closeModal: function(id) {
			$('#'+id).removeClass('active');
			$('.video')[0].contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');

			
		},
		openModal: function(id) {
			$('#'+id).addClass('active');
			setTimeout(() => {
				$('#'+id+' .video')[0].contentWindow.postMessage('{"event":"command","func":"' + 'playVideo' + '","args":""}', '*');
				setTimeout(() => {
					$('#'+id+' .video')[0].contentWindow.postMessage('{"event":"command","func":"' + 'playVideo' + '","args":""}', '*');
				}, 300);
			}, 300);
			
		},
		openBuyPackages: function(id) {
            // alert(id);
			if(id == 0) return alert('Недоступно для покупки');
			var datas = event.target;
			$.ajax({
				type: "GET",
				url: "/unitpay/loadpackages",
				data: "id="+id,
				contentType: false,
				cache: false,
			
				processData: false,
				success: function(result) {
					
					
					json = jQuery.parseJSON(result);
					console.log(json)
					if(json.error) {
						alert('Ошибка! Перезагрузите страницу');
						return 1;
					}
					
					$('#modalBuy').modal('show');
					$('#packages #id_pack').val(id);
					$('#packages .label').html('Вы собираетесь купить '+json.name+' за '+json.cost+' рублей, введите свой ник');
					
				}
			});
			
		},
		
		
	}
});